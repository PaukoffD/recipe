$('.datepicker').pickadate({
    clear: false,
    min: true,
    selectMonths: true,
    selectYears: 2,
    closeOnSelect: true,
    hiddenName: true
  });
